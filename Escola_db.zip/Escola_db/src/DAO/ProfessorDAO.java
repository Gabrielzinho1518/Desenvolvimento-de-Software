/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.Professor;
import conexao_db.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Adminstrador
 */
public class ProfessorDAO{
    private Conexao conexao;
    private Connection conn;

    public ProfessorDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir (Professor professor){
        try {
            String sql = "INSERT INTO professores(nome, idade, disciplina) VALUES (?,?,?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1,professor.getNome());
            stmt.setInt(2,professor.getIdade());
            stmt.setString(3,professor.getDisciplina());
            
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir professor:"+ex.getMessage());
        }
    } 
    
     public Professor getProfessor(int id) {
        String sql = "SELECT * FROM professores WHERE id = ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Professor professor = new Professor();

                professor.setId(rs.getInt("id"));
                professor.setNome(rs.getString("nome"));
                professor.setIdade(rs.getInt("idade"));
                professor.setDisciplina(rs.getString("disciplina"));

                return professor;
            }

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar professor: " + ex.getMessage());
        }

        return null;
    }
     
     public void editar(Professor professor) {
        try {
            String sql = "UPDATE professores SET nome = ?, idade = ?, disciplina = ? WHERE id = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, professor.getNome());
            stmt.setInt(2, professor.getIdade());
            stmt.setString(3, professor.getDisciplina());
            stmt.setInt(4, professor.getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar professor: " + ex.getMessage());
        }
    }
     
    public List<Professor> listarPorNome(String nome) {
    List<Professor> professores = new ArrayList<>();

        String sql = "SELECT * FROM professores WHERE nome LIKE ?";

        try {
            
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, "%" + nome + "%");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Professor professor = new Professor();

            professor.setId(rs.getInt("id"));
            professor.setNome(rs.getString("nome"));
            professor.setIdade(rs.getInt("idade"));
            professor.setDisciplina(rs.getString("disciplina"));

            professores.add(professor);
        }

        rs.close();
        stmt.close();

    } catch (SQLException e) {
        System.out.println("Erro ao listar professores: " + e.getMessage());
    }

    return professores;
}
    
    public List<Professor> getProfessores() {
    List<Professor> professores = new ArrayList<>();

    String sql = "SELECT * FROM professores ORDER BY nome";

    try (PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            Professor professor = new Professor();

            professor.setId(rs.getInt("id"));
            professor.setNome(rs.getString("nome"));
            professor.setIdade(rs.getInt("idade"));
            professor.setDisciplina(rs.getString("disciplina"));

            professores.add(professor);
        }

    } catch (SQLException ex) {
        throw new RuntimeException(
            "Erro ao buscar professores: " + ex.getMessage(), ex
        );
    }

    return professores;
}

    
    
     
     
}
