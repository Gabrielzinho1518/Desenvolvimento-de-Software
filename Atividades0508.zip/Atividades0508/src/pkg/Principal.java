package pkg;

public class Principal {

    public static void main(String[] args) {

        MetodoPagamento cartao = new CartaoCreditoPagamento();
        MetodoPagamento paypal = new PayPalPagamento();
        MetodoPagamento pix = new PixPagamento();

        cartao.processaPagamento(150.75);
        cartao.mostraDetalhesPagamento();

        System.out.println("---------------------");

        paypal.processaPagamento(250.00);
        paypal.mostraDetalhesPagamento();

        System.out.println("---------------------");

        pix.processaPagamento(99.90);
        pix.mostraDetalhesPagamento();
    }
}