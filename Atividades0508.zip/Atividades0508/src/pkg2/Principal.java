package pkg2;

public class Principal {

    public static void main(String[] args) {

        ICalculadora calc = new Calculadora();

        System.out.println("Soma: " + calc.somar(6, 3));
        System.out.println("Subtração: " + calc.subtrair(9, 5));
        System.out.println("Multiplicação: " + calc.multiplicar(8, 2));
        System.out.println("Divisão: " + calc.dividir(10, 5));
        System.out.println("Raiz Quadrada de 25: " + calc.raizquadrada(81, 0));
        System.out.println("Potência 2³: " + calc.elevarPotencia(1, 3));
        System.out.println("Log10 de 1000: " + calc.logaritmo10(1000));
    }
}