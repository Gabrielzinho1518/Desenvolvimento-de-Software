/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Pessoa;
import java.sql.Connection;
import conexao.Conexao;
import java.util.List;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class PessoaDAO {
    private Conexao conexao;
    private Connection conn;

    public PessoaDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public Pessoa getPessoa(int id) throws SQLException {
    String sql = "SELECT * FROM pessoa WHERE id = 2";

    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setInt(1, id);

    ResultSet rs = stmt.executeQuery();

    Pessoa p = new Pessoa();

    if (rs.next()) {
        p.setId(rs.getInt("id"));
        p.setNome(rs.getString("nome"));
        p.setSexo(rs.getString("sexo"));
        p.setIdioma(rs.getString("idioma"));
    }

    return p;
    }
    public void editar(Pessoa pessoa) {
    try {
        String sql = "UPDATE pessoa SET nome=?, sexo=?, idioma=? WHERE id=?";

        PreparedStatement stmt = this.conn.prepareStatement(sql);

        stmt.setString(1, pessoa.getNome());
        stmt.setString(2, pessoa.getSexo());
        stmt.setString(3, pessoa.getIdioma());
        stmt.setInt(4, pessoa.getId());
        stmt.executeUpdate();
        
        JOptionPane.showMessageDialog(null, "Pessoa editada com sucesso!");

    } catch (SQLException ex) {
        System.out.println("Erro ao editar pessoa: " + ex.getMessage());
    }
}
    public void excluir(int id){
        try{
            String sql ="delete from pessoa WHERE id=?";
            
            PreparedStatement smtm = conn.prepareStatement(sql);
            smtm.setInt(1, id);
            smtm.execute();
        } catch (SQLException ex){
            System.out.println("Erro ao excluir pessoa+"+ex.getMessage());
        }
    }
    
    public void inserir (Pessoa pessoa){
        try {
            String sql = "INSERT INTO pessoa(nome, sexo, idioma) VALUES (?,?,?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1,pessoa.getNome());
            stmt.setString(2,pessoa.getSexo());
            stmt.setString(3,pessoa.getIdioma());
            
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir pessoa:"+ex.getMessage());
        }
    } 
}
    
